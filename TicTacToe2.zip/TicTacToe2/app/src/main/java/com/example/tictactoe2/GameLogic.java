package com.example.tictactoe2;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class GameLogic {
    private int[][] gameBoard;

    private String[] playerNames = {"Player 1", "Player 2"};

    private Button playAgainBTN;
    private Button homeBTN;
    private TextView playerTurn;

    private int player = 1;

    GameLogic() {
        gameBoard = new int[3][3];
        for (int a = 0; a < 3; a++) {
            for (int b = 0; b < 3; b++) {
                gameBoard[a][b] = 0;
            }

        }
    }

    public boolean updateGameBoard(int row, int col){
        if(gameBoard[row-1][col-1] == 0){
            gameBoard[row-1][col-1] = player;

            if(player == 1){
                playerTurn.setText((String.format("%ss Turn", playerNames[1])));
            }
            else{
                playerTurn.setText((String.format("%ss Turn", playerNames[0])));

            }

            return true;
        }
        else{
            return false;
        }
    }

    public boolean winnerCheck(){ //true, ja ir uzvarētājs, false ja nav

        boolean isWinner = false;
        //horizontāla pārbaude
        for(int a =0; a<3; a++){
                if(gameBoard[a][0] == gameBoard[a][1] && gameBoard[a][0] == gameBoard[a][2] && gameBoard[a][0] != 0);{
                    isWinner = true;
            }

        }
        for(int b =0; b<3; b++){
            if(gameBoard[0][b] == gameBoard[1][b] && gameBoard[2][b] == gameBoard[0][b] && gameBoard[0][b] != 0);{
                isWinner = true;
            }

        }//diagonāles
            if(gameBoard[0][0] == gameBoard[1][1] && gameBoard[0][0] == gameBoard[2][2] && gameBoard[0][0] != 0);{
                isWinner = true;
            }
        if(gameBoard[2][0] == gameBoard[1][1] && gameBoard[2][0] == gameBoard[0][2] && gameBoard[2][0] != 0);{
            isWinner = true;
        }
        int boardFilled = 0;

        for(int a=0; a<3; a++){
            for(int b=0;b<3; b++){
                if(gameBoard[a][b] != 0 ){
                    boardFilled += 1;
                }
            }
        }

        if(isWinner){
            playAgainBTN.setVisibility(View.VISIBLE);
            homeBTN.setVisibility(View.VISIBLE);
            playerTurn.setText(playerNames[player-1]+ " Won!!");
            return true;

        }
        else if(boardFilled == 9){
            playAgainBTN.setVisibility(View.VISIBLE);
            homeBTN.setVisibility(View.VISIBLE);
            playerTurn.setText(" Tie game!!");
            return true;

        }
        else{
            return false;
        }
    }


    public void resetGame(){
        for (int a = 0; a < 3; a++) {
            for (int b = 0; b < 3; b++) {
                gameBoard[a][b] = 0;
            }

        }

        player =1;
        playAgainBTN.setVisibility(View.GONE);
        homeBTN.setVisibility(View.GONE);

        playerTurn.setText((String.format("%ss Turn", playerNames[0])));

    }

    public void setPlayAgainBTN(Button playAgainBTN) {
        this.playAgainBTN = playAgainBTN;
    }

    public void setHomeBTN(Button homeBTN) {
        this.homeBTN = homeBTN;
    }

    public void setPlayerTurn(TextView playerTurn) {
        this.playerTurn = playerTurn;
    }

    public void setPlayerNames(String[] playerNames) {
        this.playerNames = playerNames;
    }

    public int[][] getGameBoard() {
        return gameBoard;
    }

    public void setPlayer(int player) {
        this.player = player;
    }
    public int getPlayer(){
        return player;
    }
}
