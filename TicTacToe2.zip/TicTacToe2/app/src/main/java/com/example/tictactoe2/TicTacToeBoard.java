package com.example.tictactoe2;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class TicTacToeBoard extends View {

    private final int boardColor;
    private final int XColor;
    private final int OColor;

    private boolean winningLine = false;

    private final Paint paint = new Paint();

    private final GameLogic game;

    private int cellSize = getWidth()/3;


    public TicTacToeBoard(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        game = new GameLogic();

        TypedArray a;
        a = context.getTheme().obtainStyledAttributes(attrs, R.styleable.TicTacToeBoard,
                0,0);
        try{
            boardColor = a.getInteger(R.styleable.TicTacToeBoard_boardColor,0);
            XColor = a.getInteger(R.styleable.TicTacToeBoard_XColor,0);
            OColor = a.getInteger(R.styleable.TicTacToeBoard_OColor,0);
            int winningLineColor = a.getInteger(R.styleable.TicTacToeBoard_winningLineColor, 0);

        }finally{
            a.recycle();
        }
    }
    @Override
    protected void onMeasure(int width, int height){
        super.onMeasure(width,height);

        int dimension = Math.min(getMeasuredWidth(), getMeasuredHeight());
        cellSize = dimension/3;
        setMeasuredDimension(dimension, dimension);
    }
    @Override
    protected void onDraw(Canvas canvas){
        paint.setStyle(Paint.Style.STROKE);
        paint.setAntiAlias(true);

        drawGameBoard(canvas);
        drawMarkers(canvas);

           //drawX(canvas,1,1);
            //drawO(canvas,2,1);
    }

    @Override
    public boolean onTouchEvent (MotionEvent event){
        float x = event.getX();
        float y = event.getY();

        int action = event.getAction();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
                int row = (int) Math.ceil(y / cellSize);
                int col = (int) Math.ceil(x / cellSize);

                if (!winningLine && game.updateGameBoard(row, col)) {
                    invalidate();

                    if (game.winnerCheck()) {
                        winningLine = true;
                        invalidate();
                    }

                    // apskata vai 1 vai 2 spēlētājs ies
                    if (game.getPlayer() % 2 == 0) game.setPlayer(game.getPlayer() - 1);
                    else game.setPlayer(game.getPlayer() + 1);
                }
                invalidate();
                return true;
        }
        return false;
    }

    private void drawGameBoard(Canvas canvas){
        paint.setColor(boardColor);
        paint.setStrokeWidth(16);
        int a=1;
        while (a<3) {
            canvas.drawLine(cellSize * a, 0, cellSize * a, canvas.getWidth(), paint); //kolonnas
            a++;
        }
        int b=1;
        while (b<3) {
            canvas.drawLine(0, cellSize * b, canvas.getWidth(), cellSize * b, paint); //rindas
            b++;
        }
    }

    private void drawMarkers(Canvas canvas){
        int a;
        for (a = 0; a < 3; a++) {
            int b;
            for (b = 0; b < 3; b++)
                if (game.getGameBoard()[a][b] != 0) if (game.getGameBoard()[a][b] == 1)
                    drawX(canvas, a, b);
                else {
                    drawO(canvas, a, b);
                }
            }
        }

    private void drawX(Canvas canvas, int row, int col){
        paint.setColor(XColor);

        canvas.drawLine( (col+1)*cellSize, row*cellSize,col*cellSize, (row+1)*cellSize, paint);
        canvas.drawLine( col*cellSize, row*cellSize,(col+1)*cellSize, (row+1)*cellSize, paint);

    }
    private void drawO(Canvas canvas, int row, int col){
        paint.setColor(OColor);
        canvas.drawOval(col*cellSize,row*cellSize,(col*cellSize+cellSize),(row*cellSize+cellSize),paint);

    }
    public void setUpGame(Button playAgain, Button home, TextView playerDisplay, String[] names){
        game.setPlayAgainBTN(playAgain);
        game.setHomeBTN(home);
        game.setPlayerTurn(playerDisplay);
        game.setPlayerNames(names);
    }
    public void resetGame(){

        game.resetGame();
        winningLine = false;

    }

}
